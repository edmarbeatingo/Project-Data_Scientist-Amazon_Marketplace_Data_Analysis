import pandas as pd
import json

# Define the mapping from JSON fields to DataFrame columns
field_mapping = {
    "marketplaceId": "Amazon store",
    "startDate": "Start date",
    "endDate": "End date",
    "parentAsin": "Parent ASIN",
    "childAsin": "ASIN",
    "fnsku": "FNSKU",
    "msku": "MSKU",
    "netProceeds.perUnit.currencyCode": "Currency code",
    "sales.averageSellingPrice.amount": "Average sales price",
    "sales.netUnitsSold": "Units sold",
    "sales.unitsRefunded": "Units returned",
    "sales.netUnitsSold": "Net units sold",
    "sales.orderedProductSales.amount": "Sales",
    "sales.netProductSales.amount": "Net sales",
    "fees.BaseFbaFulfilmentFee.aggregatedDetail.amountPerUnit.amount": "Base fulfilment fee per unit",
    "fees.BaseFbaFulfilmentFee.aggregatedDetail.quantity": "Base fulfilment fee quantity",
    "fees.BaseFbaFulfilmentFee.aggregatedDetail.totalAmount.amount": "Base fulfilment fee total",
    "fees.FbaFulfilmentFee.aggregatedDetail.amountPerUnit.amount": "Fulfilment by Amazon fulfilment fees per unit",
    "fees.FbaFulfilmentFee.aggregatedDetail.quantity": "Fulfilment by Amazon fulfilment fees quantity",
    "fees.FbaFulfilmentFee.aggregatedDetail.totalAmount.amount": "Fulfilment by Amazon fulfilment fees total",
    "fees.FbaInboundTransportationProgramFee.aggregatedDetail.amountPerUnit.amount": "Inbound Transportation Program Fee per unit",
    "fees.FbaInboundTransportationProgramFee.aggregatedDetail.quantity": "Inbound Transportation Program Fee quantity",
    "fees.FbaInboundTransportationProgramFee.aggregatedDetail.totalAmount.amount": "Inbound Transportation Program Fee total",
    "fees.FbaInboundTransportationFee.aggregatedDetail.amountPerUnit.amount": "Inbound transportation charge per unit",
    "fees.FbaInboundTransportationFee.aggregatedDetail.quantity": "Inbound transportation charge quantity",
    "fees.FbaInboundTransportationFee.aggregatedDetail.totalAmount.amount": "Inbound transportation charge total",
    "fees.LowInventoryLevelFee.aggregatedDetail.amountPerUnit.amount": "Low-inventory-level fee per unit",
    "fees.LowInventoryLevelFee.aggregatedDetail.quantity": "Low-inventory-level fee quantity",
    "fees.LowInventoryLevelFee.aggregatedDetail.totalAmount.amount": "Low-inventory-level fee total",
    "fees.ReferralFee.aggregatedDetail.amountPerUnit.amount": "Referral fee per unit",
    "fees.ReferralFee.aggregatedDetail.quantity": "Referral fee quantity",
    "fees.ReferralFee.aggregatedDetail.totalAmount.amount": "Referral fee total",
    "fees.RefundCommissionFee.aggregatedDetail.amountPerUnit.amount": "Refund administration fee per unit",
    "fees.RefundCommissionFee.aggregatedDetail.quantity": "Refund administration fee quantity",
    "fees.RefundCommissionFee.aggregatedDetail.totalAmount.amount": "Refund administration fee total",
    "ads.SponsoredProductFee.charge.amountPerUnit.amount": "Sponsored Products charge per unit",
    "ads.SponsoredProductFee.charge.quantity": "Sponsored Products charge quantity",
    "ads.SponsoredProductFee.charge.totalAmount.amount": "Sponsored Products charge total",
    "cost.costOfGoodsSold": "Cost of goods sold per unit",
    "cost.miscellaneousCost": "Miscellaneous cost per unit",
    "netProceeds.total.amount": "Net proceeds total",
    "netProceeds.perUnit.amount": "Net proceeds per unit"
}

# Define the required columns
required_columns = [
    "Amazon store", "Start date", "End date", "Parent ASIN", "ASIN",
    "FNSKU", "MSKU", "Currency code", "Average sales price", "Units sold",
    "Units returned", "Net units sold", "Sales", "Net sales",
    "Base fulfilment fee per unit", "Base fulfilment fee quantity",
    "Base fulfilment fee total", "Fulfilment by Amazon fulfilment fees per unit",
    "Fulfilment by Amazon fulfilment fees quantity", "Fulfilment by Amazon fulfilment fees total",
    "Inbound Transportation Program Fee per unit", "Inbound Transportation Program Fee quantity",
    "Inbound Transportation Program Fee total", "Inbound transportation charge per unit",
    "Inbound transportation charge quantity", "Inbound transportation charge total",
    "Low-inventory-level fee per unit", "Low-inventory-level fee quantity",
    "Low-inventory-level fee total", "Referral fee per unit", "Referral fee quantity",
    "Referral fee total", "Refund administration fee per unit", "Refund administration fee quantity",
    "Refund administration fee total", "Sponsored Products charge per unit",
    "Sponsored Products charge quantity", "Sponsored Products charge total",
    "Cost of goods sold per unit", "Miscellaneous cost per unit", "Net proceeds total",
    "Net proceeds per unit"
]

# Read the JSON data from the text file
with open('C:/Users/Edmar Beatingo/Downloads/test_data.txt', 'r') as file:
    data = [json.loads(line) for line in file]

# Function to extract nested fields
def extract_keys(data, parent_key=''):
    keys = set()
    if isinstance(data, dict):
        for k, v in data.items():
            full_key = f"{parent_key}.{k}" if parent_key else k
            keys.add(full_key)
            keys.update(extract_keys(v, full_key))
    elif isinstance(data, list):
        for item in data:
            keys.update(extract_keys(item, parent_key))
    return keys

# Function to extract a specific field from nested JSON
def extract_field(data, field):
    keys = field.split('.')
    for key in keys:
        if isinstance(data, list):
            data = data[0] if data else None
        if data and key in data:
            data = data[key]
        else:
            return None
    return data

all_keys = set()
for entry in data:
    all_keys.update(extract_keys(entry))

# Map JSON keys to DataFrame columns
mapped_columns = set(field_mapping.values())

# Identify unmatching columns
unmatching_columns = set(required_columns) - mapped_columns
unmapped_json_keys = all_keys - set(field_mapping.keys())

print("Unmatching Required Columns:")
print(unmatching_columns)

print("\nUnmapped JSON Keys:")
print(unmapped_json_keys)

# Add missing mappings to field_mapping
for column in unmatching_columns:
    # Attempt to find a matching key in all_keys
    for key in all_keys:
        if column.lower().replace(" ", "_") in key.lower().replace(".", "_"):
            field_mapping[key] = column
            break

# Create a list of dictionaries with the required fields
formatted_data = []
for entry in data:
    formatted_entry = {}
    for json_field, df_field in field_mapping.items():
        formatted_entry[df_field] = extract_field(entry, json_field)
    formatted_data.append(formatted_entry)

# Create a DataFrame from the formatted data
df = pd.DataFrame(formatted_data, columns=required_columns)

# Fill missing values with "null"
df = df.fillna("null")

# Print the DataFrame columns
print("DataFrame Columns:")
print(df.columns)

# Print the DataFrame
print(df)

# Save the DataFrame to a CSV file (optional)
df.to_csv('C:/Users/Edmar Beatingo/Downloads/formatted_data.csv', index=False)