import pandas as pd

# Read the CSV data
df = pd.read_csv('C:/Users/Edmar Beatingo/Downloads/updated_data.csv')

# Remove duplicate rows
df = df.drop_duplicates()

# Convert date columns to datetime format
df['Start date'] = pd.to_datetime(df['Start date'], errors='coerce')
df['End date'] = pd.to_datetime(df['End date'], errors='coerce')

# Convert numeric columns to appropriate numeric types
numeric_columns = [
    'Average sales price', 'Units sold', 'Units returned', 'Net units sold',
    'Sales', 'Net sales', 'Net proceeds total', 'Net proceeds per unit', 'Return rate'
]

for column in numeric_columns:
    df[column] = pd.to_numeric(df[column], errors='coerce')

# Handle any remaining missing values (e.g., fill with 0 or appropriate value)
df = df.fillna({
    'Average sales price': 0.0,
    'Units sold': 0,
    'Units returned': 0,
    'Net units sold': 0,
    'Sales': 0.0,
    'Net sales': 0.0,
    'Net proceeds total': 0.0,
    'Net proceeds per unit': 0.0
})

# Print the cleaned DataFrame
print("Cleaned DataFrame:")
print(df)

# Save the cleaned and formatted DataFrame to a CSV file
df.to_csv('C:/Users/Edmar Beatingo/Downloads/cleaned_data.csv', index=False)