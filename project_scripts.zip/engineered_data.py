import pandas as pd

# Read the CSV data
df = pd.read_csv('C:/Users/Edmar Beatingo/Downloads/formatted_data.csv')

# Replace null values in "Units sold" with the sum of "Net units sold" and "Units returned"
df['Units sold'] = df['Units sold'].fillna(df['Net units sold'] + df['Units returned'])

# Remove all columns that are either empty or contain only null values
df_cleaned = df.dropna(axis=1, how='all')

# Compute return rates
df_cleaned['Return rate'] = df_cleaned['Units returned'] / df_cleaned['Units sold']

# Handle any resulting NaN values by filling them with zero
df_cleaned = df_cleaned.fillna(0)

# Print the updated DataFrame
print("Updated DataFrame with computed 'Units sold', 'Return rate', and removed empty/null columns:")
print(df_cleaned)

# Save the updated DataFrame to a CSV file
df_cleaned.to_csv('C:/Users/Edmar Beatingo/Downloads/updated_data.csv', index=False)